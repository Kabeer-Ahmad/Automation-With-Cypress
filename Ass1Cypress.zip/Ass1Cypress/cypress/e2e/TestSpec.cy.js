// cypress/e2e/saucedemo.spec.js
import LoginPage from '../pages/LoginPage';
import HomePage from '../pages/HomePage';
import ProductPage from '../pages/ProductPage';

describe('SauceDemo Test Suite', () => {
    const loginPage = new LoginPage();
    const homePage = new HomePage();
    const productPage = new ProductPage();

    beforeEach(() => {
        loginPage.visit();
    });

    it('Should display an error message on wrong login', () => {
        cy.login('wrong_user', 'wrong_pass');
        cy.verifyErrorMessage('Epic sadface: Username and password do not match any user in this service');
    });

    it('Should login and land on home page', () => {
        cy.login('standard_user', 'secret_sauce');
        homePage.getTitle().should('contain.text', 'Products');
    });

    it('Should navigate to product page', () => {
        cy.login('standard_user', 'secret_sauce');
        homePage.clickProduct('Sauce Labs Backpack');
        productPage.getProductTitle().should('contain.text', 'Sauce Labs Backpack');
    });
});
