class HomePage {
    getTitle() {
        return cy.get('.title');
    }

    clickProduct(productName) {
        cy.contains(productName).click();
    }
}

export default HomePage;
