Cypress.Commands.add('login', (username, password) => {
    cy.get('#user-name').type(username);
    cy.get('#password').type(password);
    cy.get('#login-button').click();
});

Cypress.Commands.add('verifyErrorMessage', (message) => {
    cy.get('[data-test="error"]').should('contain.text', message);
});
